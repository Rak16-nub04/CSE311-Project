<?php
session_start();


session_destroy();


$redirect = isset($_GET['redirect']) ? $_GET['redirect'] : 'home.html';
header("Location: $redirect");
exit();
?>
