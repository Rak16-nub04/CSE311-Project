<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: signin.php");
    exit();
}

include 'connect.php';

$username = $_SESSION['username'];
$sql = "SELECT * FROM signup WHERE username='$username'";
$result = mysqli_query($con, $sql);

if ($result && mysqli_num_rows($result) > 0) {
    $user = mysqli_fetch_assoc($result);
} else {
    echo "User not found.";
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['update'])) {
        
        $full_name = $_POST['Full_Name'];
        $email = $_POST['Email'];
        $phone = $_POST['Phone'];
        $dob = $_POST['DoB'];

        
        $update_sql = "UPDATE signup SET Full_Name='$full_name', Email='$email', Phone='$phone', DoB='$dob' WHERE username='$username'";
        if (mysqli_query($con, $update_sql)) {
            
            $user['Full_Name'] = $full_name;
            $user['Email'] = $email;
            $user['Phone'] = $phone;
            $user['DoB'] = $dob;
            $update_success = "Profile updated successfully.";
        } else {
            $update_error = "Failed to update profile. Please try again.";
        }
    } elseif (isset($_POST['delete_confirmed'])) {
        
        $delete_sql = "DELETE FROM signup WHERE username='$username'";
        if (mysqli_query($con, $delete_sql)) {
            
            session_destroy();
            header("Location: home.html");
            exit();
        } else {
            $delete_error = "Failed to delete account. Please try again.";
        }
    }
}
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css">
    <title>Profile</title>
</head>
<body>
<div class="container mt-5">
    <h1 class="text-center text-primary">Profile Details</h1>
    <div class="card mx-auto" style="max-width: 500px;">
        <div class="card-body">
            <?php
            if (isset($update_success)) {
                echo '<div class="alert alert-success" role="alert">' . $update_success . '</div>';
            }
            if (isset($update_error)) {
                echo '<div class="alert alert-danger" role="alert">' . $update_error . '</div>';
            }
            if (isset($delete_error)) {
                echo '<div class="alert alert-danger" role="alert">' . $delete_error . '</div>';
            }
            ?>
            <form method="post" action="profile.php">
                <div class="form-group">
                    <label for="Full_Name">Full Name</label>
                    <input type="text" class="form-control" id="Full_Name" name="Full_Name" value="<?php echo htmlspecialchars($user['Full_Name']); ?>" required>
                </div>
                <div class="form-group">
                    <label for="Email">Email</label>
                    <input type="email" class="form-control" id="Email" name="Email" value="<?php echo htmlspecialchars($user['Email']); ?>" required>
                </div>
                <div class="form-group">
                    <label for="Phone">Phone</label>
                    <input type="text" class="form-control" id="Phone" name="Phone" value="<?php echo htmlspecialchars($user['Phone']); ?>" required>
                </div>
                <div class="form-group">
                    <label for="DoB">Date of Birth</label>
                    <input type="date" class="form-control" id="DoB" name="DoB" value="<?php echo htmlspecialchars($user['DoB']); ?>" required>
                </div>
                <button type="submit" name="update" class="btn btn-primary">Update Profile</button>
                <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#deleteModal">Delete Account</button>
            </form>
            <a href="logout.php" class="btn btn-primary mt-3">Logout</a>
        </div>
    </div>
</div>


<div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="deleteModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="deleteModalLabel">Confirm Delete</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                Are you sure you want to delete your account? This action cannot be undone.
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                <form method="post" action="profile.php">
                    <button type="submit" name="delete_confirmed" class="btn btn-danger">Delete</button>
                </form>
            </div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js"></script>

</body>
</html>
