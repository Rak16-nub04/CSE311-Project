
<?php
$success = 0;
$user = 0;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    include 'connect.php';

    $username = $_POST['username'];
    $fullname = $_POST['Full_Name'];
    $email = $_POST['Email'];
    $phone = $_POST['Phone'];
    $dob = $_POST['DoB'];
    $password = $_POST['Password'];

    $sql = "SELECT * FROM signup WHERE username = '$username'";
    $result = mysqli_query($con, $sql);

    if ($result && mysqli_num_rows($result) > 0) {
        $user = 1;
    } else {
        $sql = "INSERT INTO signup (username, Full_Name, Email, Phone, DoB, Password) VALUES ('$username', '$fullname', '$email', '$phone', '$dob', '$password')";
        $result = mysqli_query($con, $sql);
        if ($result) {
            $success = 1;
        } else {
            die(mysqli_error($con));
        }
    }
}
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css">
    <title>Sign Up Page</title>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <div class="container-fluid justify-content-end"> 
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link" href="home.html">Home Page</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="home1.html">Profile Page</a>
            </li>
        </ul>
    </div>
</nav>


<?php if ($user): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <strong>Sorry!</strong> User already exists.Please use a different Unique USERNAME
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
<?php endif; ?>

<?php if ($success): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>Congratulations!</strong> You have successfully signed up.
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
<?php endif; ?>

<div class="container mt-5">
    <h1 class="text-center">Sign Up Page</h1>
    <form action="signup.php" method="post" autocomplete="off">
        <div class="mb-3">
            <label for="username">Username</label>
            <input type="text" class="form-control" id="username" name="username" placeholder="Enter a unique username" required>
        </div>
        <div class="mb-3">
            <label for="fullname">Full Name</label>
            <input type="text" class="form-control" id="fullname" name="Full_Name" placeholder="Enter your full name" required>
        </div>
        <div class="mb-3">
            <label for="dob">Date of Birth</label>
            <input type="date" class="form-control" id="dob" name="DoB" required>
        </div>
        <div class="mb-3">
            <label for="email">Email</label>
            <input type="email" class="form-control" id="email" name="Email" placeholder="Enter your email address" required>
        </div>
        <div class="mb-3">
            <label for="phone">Phone No.</label>
            <input type="tel" class="form-control" id="phone" name="Phone" placeholder="Enter your phone number" required>
        </div>
        <div class="mb-3">
            <label for="password">Password</label>
            <input type="password" class="form-control" id="password" name="Password" placeholder="Enter your password" required>
        </div>
        <button type="submit" class="btn btn-primary w-100">Submit</button>
    </form>
    <div class="mt-3 text-center">
        <p>Already have an account? <a href="signin.php">Sign In</a></p>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js"></script>

</body>
</html>
