<?php
$HOSTNAME= 'localhost';
$USERNAME= 'rakib';
$PASSWORD= 'password';
$DATABASE= 'project';

$con=mysqli_connect($HOSTNAME,$USERNAME,$PASSWORD,$DATABASE);

if(!$con){
   
    die(mysqli_error($con));
}

?>

