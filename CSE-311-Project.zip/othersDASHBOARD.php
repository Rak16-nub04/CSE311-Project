<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Others Dashboard</title>
    <link rel="stylesheet" type="text/css" href="othersSTYLE.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    
</head>
<body>
    <?php
    session_start();
    if (!isset($_SESSION['username'])) {
        header("Location: signin.php");
        exit();
    }

    
    include 'connect.php';

    
    $success_message = $error_message = '';

    
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        
        $event_name = $_POST['event_name'];
        $event_location = $_POST['event_location'];
        $event_details = $_POST['event_details'];
        $comments = $_POST['comments'];
        $phone_number = $_POST['phone_number']; /

        
        $insert_query = "INSERT INTO others_events (event_name, event_location, event_details, comments, phone_number) VALUES (?, ?, ?, ?, ?)";
        $stmt = $con->prepare($insert_query);
        $stmt->bind_param("sssss", $event_name, $event_location, $event_details, $comments, $phone_number);

        if ($stmt->execute()) {
            
            $success_message = "Event added successfully! Thanks for being with us.";
        } else {
           
            $error_message = "Failed to add event. Please try again.";
        }

        $stmt->close();
    }

    $con->close();
    ?>

    <nav class="navbar navbar-expand-lg navbar-light bg-light navbar-custom">
        <a class="navbar-brand" href="dashboard.html">Go Back to Main Dashboard</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto"> 
                <li class="nav-item">
                    <a class="nav-link" href="home.html">Home Page</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="home1.html">Profile Page</a>
                </li>
            </ul>
        </div>
    </nav>

    <div class="container mt-5">
        <h1 style="text-align: center;">Welcome to Others Dashboard</h1>

        
        <?php if (!empty($success_message)) : ?>
            <div class="alert alert-success"><?php echo $success_message; ?></div>
        <?php endif; ?>
        <?php if (!empty($error_message)) : ?>
            <div class="alert alert-danger"><?php echo $error_message; ?></div>
        <?php endif; ?>

      
        <div>
            <h2 style="text-align: center;">Add Event</h2>
            <form action="" method="post">
                <div class="form-group">
                    <label for="event_name">Event Name:</label>
                    <input type="text" id="event_name" name="event_name" class="form-control" required>
                </div>
                <div class="form-group">
                    <label for="event_location">Event Location:</label>
                    <input type="text" id="event_location" name="event_location" class="form-control" required>
                </div>
                <div class="form-group">
                    <label for="event_details">Event Details:</label>
                    <textarea id="event_details" name="event_details" class="form-control" required></textarea>
                </div>
                <div class="form-group">
                    <label for="phone_number">Phone Number:</label> 
                    <input type="text" id="phone_number" name="phone_number" class="form-control" required>
                </div>
                <div class="form-group">
                    <label for="comments">Comments:</label>
                    <textarea id="comments" name="comments" class="form-control"></textarea>
                </div>
                
                <button type="submit" class="btn btn-primary">Submit</button>
            </form>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
