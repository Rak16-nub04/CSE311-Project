<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: signin.php");
    exit();
}


include 'connect.php';


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    $event_name = $_POST['event_name'];
    $event_location = $_POST['event_location'];
    $event_details = $_POST['event_details'];
    $comments = $_POST['comments'];
    $phone_number = $_POST['phone_number'];

    
    $insert_query = "INSERT INTO others_events (event_name, event_location, event_details, comments, phone_number) VALUES (?, ?, ?, ?, ?)";
    $stmt = $con->prepare($insert_query);
    $stmt->bind_param("sssss", $event_name, $event_location, $event_details, $comments, $phone_number);

    if ($stmt->execute()) {
      
        $_SESSION['success_message'] = "Event added successfully!";
        header("Location: othersDASHBOARD.php");
        exit();
    } else {
        
        $_SESSION['error_message'] = "Failed to add event. Please try again.";
        header("Location: othersDASHBOARD.php");
        exit();
    }

    $stmt->close();
}

$con->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Others Dashboard</title>
    <link rel="stylesheet" type="text/css" href="othersprocessSTYLE.css">
</head>
<body>

<?php if (isset($_SESSION['success_message'])) : ?>
    <div class="success-message"><?php echo $_SESSION['success_message']; ?></div>
    <?php unset($_SESSION['success_message']); ?>
<?php endif; ?>

<?php if (isset($_SESSION['error_message'])) : ?>
    <div class="error-message"><?php echo $_SESSION['error_message']; ?></div>
    <?php unset($_SESSION['error_message']); ?>
<?php endif; ?>


<h2>Add Event</h2>
<form action="" method="post"> 
    
</form>

</body>
</html>
