<?php
include 'connect.php';
session_start();

if (!isset($_SESSION['username']) || !$_SESSION['is_admin']) {
    header("Location: adminSIGNIN.php");
    exit();
}

if (isset($_GET['id'])) {
    $userId = $_GET['id'];
    $sql = "SELECT * FROM signup WHERE id=$userId";
    $result = mysqli_query($con, $sql);
    $user = mysqli_fetch_assoc($result);
} else {
    header("Location: admin.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit User</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <h2>Edit User</h2>
    <form method="post" action="admin.php">
        <input type="hidden" name="user_id" value="<?= $user['id'] ?>">
        <label for="full_name">Full Name:</label>
        <input type="text" id="full_name" name="full_name" value="<?= htmlspecialchars($user['Full_Name']) ?>" required>
        <br>
        <label for="email">Email:</label>
        <input type="email" id="email" name="email" value="<?= htmlspecialchars($user['Email']) ?>" required>
        <br>
        <label for="phone">Phone:</label>
        <input type="text" id="phone" name="phone" value="<?= htmlspecialchars($user['Phone']) ?>" required>
        <br>
        <label for="dob">Date of Birth:</label>
        <input type="date" id="dob" name="dob" value="<?= $user['DoB'] ?>" required>
        <br>
        <label for="is_admin">Admin:</label>
        <input type="checkbox" id="is_admin" name="is_admin" <?= $user['is_admin'] ? 'checked' : '' ?>>
        <br>
        <button type="submit" name="update_user">Update User</button>
    </form>
</body>
</html>
