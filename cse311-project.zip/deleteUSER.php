<?php
include 'connect.php';


if (isset($_POST['userid'])) {
    $userid = $_POST['userid'];
    $sql = "DELETE FROM signup WHERE userid = $userid";
    if (mysqli_query($con, $sql)) {
        
        header("Location: admin.php");
        exit();
    } else {
        echo "Failed to delete user.";
    }
}
?>
