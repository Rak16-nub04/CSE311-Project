<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: signin.php");
    exit();
}

include 'connect.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $event_id = $_POST['event_id'];
    $name = $_POST['name'];
    $age = $_POST['age'];
    $nid = $_POST['nid'];
    $num_tickets = $_POST['num_tickets'];
    $payment_method = $_POST['payment_method'];
    $amount_to_pay = $_POST['money'];

    
    $nid_check_query = "SELECT id FROM musical_ticket WHERE nid = ?";
    $nid_check_stmt = $con->prepare($nid_check_query);
    $nid_check_stmt->bind_param("s", $nid);
    $nid_check_stmt->execute();
    $nid_check_result = $nid_check_stmt->get_result();

    if ($nid_check_result->num_rows > 0) {
        
        $_SESSION['nid_error'] = "The NID already exists. Please use a different NID.";
        header("Location: musicalTICKET.php?event_id=$event_id");
        exit();
    } else {
        
        $stmt = $con->prepare("INSERT INTO musical_ticket (event_id, name, age, nid, num_tickets, amount_paid,payment_method) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("isisiis", $event_id, $name, $age, $nid, $num_tickets,  $amount_to_pay,$payment_method,);

        if ($stmt->execute()) {
            $ticket_id = $stmt->insert_id;
            header("Location: musicalTICKETprint.php?ticket_id=" . $ticket_id);
            exit();
        } else {
            echo "Error: " . $stmt->error;
        }

        $stmt->close();
    }

    $nid_check_stmt->close();
}

$con->close();
?>
