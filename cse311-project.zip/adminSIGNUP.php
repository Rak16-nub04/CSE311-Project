<?php

$hostname = 'localhost';
$username = 'your_username';
$password = 'your_password';
$database = 'your_database';

$con = mysqli_connect($hostname, $username, $password, $database);
if (!$con) {
    die(mysqli_error($con));
}


if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT); 
    $query = "INSERT INTO admins (username, password) VALUES ('$username', '$password')";
    $result = mysqli_query($con, $query);
    if ($result) {
        
        header("Location: adminSIGNIN.php");
        exit();
    } else {
        echo "Signup failed!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Signup</title>
</head>
<body>
    <h1>Admin Signup</h1>
    <form method="post">
        <label for="username">Username:</label>
        <input type="text" id="username" name="username" required><br><br>
        <label for="password">Password:</label>
        <input type="password" id="password" name="password" required><br><br>
        <button type="submit">Sign Up</button>
    </form>
</body>
</html>
